#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_QUESTIONS 20
#define MAX_LINE 512
#define HISTORY_FILE "results.txt"

void clear_input_buffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* Discard remaining input. */
    }
}

char get_choice(void) {
    char line[32];

    while (1) {
        if (fgets(line, sizeof(line), stdin) == NULL) {
            return '\0';
        }

        if (line[0] == '\n') {
            continue;
        }

        char ch = line[0];

        if (ch == 'a' || ch == 'A') return 'a';
        if (ch == 'b' || ch == 'B') return 'b';
        if (ch >= '1' && ch <= '5') return ch;

        printf("Invalid input. Try again: ");
    }
}

void press_enter_to_continue(void) {
    printf("\nPress Enter to continue...");
    clear_input_buffer();
}

void save_result(const char *mbti, const char *mood, const int scores[4]) {
    FILE *file = fopen(HISTORY_FILE, "a");

    if (file == NULL) {
        printf("Warning: Could not open %s to save the result.\n", HISTORY_FILE);
        return;
    }

    time_t now = time(NULL);
    struct tm *local_time = localtime(&now);

    if (local_time != NULL) {
        fprintf(file,
                "Date: %04d-%02d-%02d %02d:%02d:%02d | Mood: %s | MBTI: %s | "
                "Scores: E/I=%d N/S=%d F/T=%d J/P=%d\n",
                local_time->tm_year + 1900,
                local_time->tm_mon + 1,
                local_time->tm_mday,
                local_time->tm_hour,
                local_time->tm_min,
                local_time->tm_sec,
                mood, mbti,
                scores[0], scores[1], scores[2], scores[3]);
    }

    fclose(file);
}

void view_history(void) {
    FILE *file = fopen(HISTORY_FILE, "r");

    if (file == NULL) {
        printf("\nNo history found. Take a test first!\n");
        return;
    }

    char line[MAX_LINE];
    printf("\n==================== Test History ====================\n");

    while (fgets(line, sizeof(line), file) != NULL) {
        printf("%s", line);
    }

    printf("=======================================================\n");
    fclose(file);
}

/*
 * Each score is a signed total:
 * positive = E, N, F, or J; negative = I, S, T, or P.
 */
void determine_mbti(const int scores[4], char out[5]) {
    out[0] = (scores[0] >= 0) ? 'E' : 'I';
    out[1] = (scores[1] >= 0) ? 'N' : 'S';
    out[2] = (scores[2] >= 0) ? 'F' : 'T';
    out[3] = (scores[3] >= 0) ? 'J' : 'P';
    out[4] = '\0';
}

void show_description(const char mbti[5], const char *mood) {
    printf("\n============================================\n");
    printf("              YOUR MBTI TYPE: %s\n", mbti);
    printf("============================================\n\n");

    if (strcmp(mbti, "INFJ") == 0) {
        printf("THE ADVOCATE\n");
        printf("Creative, compassionate, and visionary. You focus on meaningful connections.\n");
        printf("You have strong intuition and like planning your future carefully.\n");
    } else if (strcmp(mbti, "INTJ") == 0) {
        printf("THE ARCHITECT\n");
        printf("Strategic, independent, and analytical. You excel at solving complex problems.\n");
        printf("You plan ahead and trust your insights.\n");
    } else if (strcmp(mbti, "INFP") == 0) {
        printf("THE MEDIATOR\n");
        printf("Idealistic, loyal, and values-driven. You seek harmony and authenticity.\n");
        printf("You are empathetic and enjoy creative expression.\n");
    } else if (strcmp(mbti, "INTP") == 0) {
        printf("THE LOGICIAN\n");
        printf("Innovative, curious, and logical. You love analyzing theories and ideas.\n");
        printf("You value knowledge and enjoy intellectual challenges.\n");
    } else if (strcmp(mbti, "ENFJ") == 0) {
        printf("THE PROTAGONIST\n");
        printf("Charismatic, inspiring, and empathetic. You care deeply about others.\n");
        printf("You enjoy helping people reach their potential.\n");
    } else if (strcmp(mbti, "ENTJ") == 0) {
        printf("THE COMMANDER\n");
        printf("Bold, strategic, and decisive. You enjoy challenges and leadership.\n");
        printf("You are good at organizing people and resources.\n");
    } else if (strcmp(mbti, "ENFP") == 0) {
        printf("THE CAMPAIGNER\n");
        printf("Enthusiastic, imaginative, and sociable. You enjoy exploring new ideas.\n");
        printf("You value freedom and creativity.\n");
    } else if (strcmp(mbti, "ENTP") == 0) {
        printf("THE DEBATER\n");
        printf("Inventive, curious, and loves debate. You enjoy challenging ideas.\n");
        printf("You are adaptable and enjoy intellectual stimulation.\n");
    } else if (strcmp(mbti, "ISTJ") == 0) {
        printf("THE LOGISTICIAN\n");
        printf("Reliable, practical, and organized. You follow rules and prefer routines.\n");
        printf("You are responsible and detail-oriented.\n");
    } else if (strcmp(mbti, "ISFJ") == 0) {
        printf("THE DEFENDER\n");
        printf("Warm, loyal, and dedicated. You care about protecting and helping others.\n");
        printf("You value tradition and harmony.\n");
    } else if (strcmp(mbti, "ISTP") == 0) {
        printf("THE VIRTUOSO\n");
        printf("Bold, practical, and hands-on. You are good at troubleshooting.\n");
        printf("You enjoy understanding how things work.\n");
    } else if (strcmp(mbti, "ISFP") == 0) {
        printf("THE ADVENTURER\n");
        printf("Quiet, friendly, and sensitive to beauty. You enjoy the present moment.\n");
        printf("You are empathetic, artistic, and value personal freedom.\n");
    } else if (strcmp(mbti, "ESTJ") == 0) {
        printf("THE EXECUTIVE\n");
        printf("Organized, practical, and decisive. You are good at managing projects.\n");
        printf("You value order and clear standards.\n");
    } else if (strcmp(mbti, "ESFJ") == 0) {
        printf("THE CONSUL\n");
        printf("Caring, social, and helpful. You value harmony and cooperation.\n");
        printf("You enjoy bringing people together.\n");
    } else if (strcmp(mbti, "ESTP") == 0) {
        printf("THE ENTREPRENEUR\n");
        printf("Energetic, perceptive, and action-oriented. You enjoy taking action.\n");
        printf("You respond quickly to changing situations.\n");
    } else if (strcmp(mbti, "ESFP") == 0) {
        printf("THE ENTERTAINER\n");
        printf("Spontaneous, enthusiastic, and fun-loving. You enjoy life and people.\n");
        printf("You like bringing joy to others.\n");
    }

    printf("\n--- Mood-Aware Tip ---\n");

    if (strcmp(mood, "happy") == 0) {
        printf("Celebrate small wins and enjoy your positive energy!\n");
    } else if (strcmp(mood, "sad") == 0) {
        printf("Be gentle with yourself. It is okay to rest and reflect.\n");
    } else if (strcmp(mood, "anxious") == 0) {
        printf("Take deep breaths. Break tasks into small steps and take breaks.\n");
    } else if (strcmp(mood, "calm") == 0) {
        printf("Use this clarity to make thoughtful decisions and plan ahead.\n");
    } else {
        printf("Stay mindful and observe your emotions without judgment.\n");
    }

    printf("============================================\n");
}

void ask_questions(int scores[4],
                   const char *questions[],
                   const char *answers_a[],
                   const char *answers_b[],
                   const int dimensions[],
                   const int a_polarity[]) {
    printf("\n** Answer honestly for your own reflection **\n");

    for (int i = 0; i < MAX_QUESTIONS; ++i) {
        printf("\n----------------------------------------\n");
        printf("Question %02d/%d:\n%s\n", i + 1, MAX_QUESTIONS, questions[i]);
        printf("   a) %s\n", answers_a[i]);
        printf("   b) %s\n", answers_b[i]);
        printf("\nYour answer (a/b): ");

        char choice = get_choice();

        if (choice == 'a') {
            scores[dimensions[i]] += a_polarity[i];
        } else if (choice == 'b') {
            scores[dimensions[i]] -= a_polarity[i];
        } else {
            printf("Input ended. No answer recorded.\n");
            return;
        }
    }
}

void build_questions(const char *questions[],
                     const char *answers_a[],
                     const char *answers_b[]) {
    questions[0] = "When you have free time, do you prefer to be with others or alone?";
    answers_a[0] = "I enjoy being around people and social energy.";
    answers_b[0] = "I prefer quiet time to reflect and recharge.";

    questions[1] = "Do you focus more on details or big-picture ideas?";
    answers_a[1] = "I focus on big-picture ideas and possibilities.";
    answers_b[1] = "I focus on details and concrete facts.";

    questions[2] = "When making decisions, do you rely on logic or feelings?";
    answers_a[2] = "I rely on feelings and harmony.";
    answers_b[2] = "I rely on logic and analysis.";

    questions[3] = "Do you prefer planning or spontaneity?";
    answers_a[3] = "I prefer planning and schedules.";
    answers_b[3] = "I enjoy being spontaneous and flexible.";

    questions[4] = "Do social events energize you or tire you?";
    answers_a[4] = "I get energy from social events.";
    answers_b[4] = "Social events tire me; I need alone time.";

    questions[5] = "Do you trust experience or intuition more?";
    answers_a[5] = "I trust intuition and patterns.";
    answers_b[5] = "I trust experience and evidence.";

    questions[6] = "Are you more persuaded by fairness or empathy?";
    answers_a[6] = "I am persuaded by empathy and personal values.";
    answers_b[6] = "I am persuaded by rules and fairness.";

    questions[7] = "Do you like finishing tasks early or keeping options open?";
    answers_a[7] = "I keep options open and adapt.";
    answers_b[7] = "I finish tasks early and close options.";

    questions[8] = "Do you enjoy talking through ideas or thinking them through alone?";
    answers_a[8] = "I like discussing ideas with others.";
    answers_b[8] = "I prefer thinking through ideas alone.";

    questions[9] = "Do you prefer structured instructions or flexible possibilities?";
    answers_a[9] = "I enjoy open-ended creative tasks.";
    answers_b[9] = "I like clear step-by-step instructions.";

    questions[10] = "Do you make choices from values or reason?";
    answers_a[10] = "I make choices based on values and feelings.";
    answers_b[10] = "I make choices based on logic and reason.";

    questions[11] = "Do you feel comfortable with routines or change?";
    answers_a[11] = "I enjoy change and novelty.";
    answers_b[11] = "I prefer routines and predictability.";

    questions[12] = "Do you notice patterns or concrete details?";
    answers_a[12] = "I notice patterns and connections.";
    answers_b[12] = "I notice concrete facts and details.";

    questions[13] = "Do you prefer supportive feedback or objective critiques?";
    answers_a[13] = "Supportive feedback helps me most.";
    answers_b[13] = "Objective critiques help me improve.";

    questions[14] = "Do you plan your day or go with the flow?";
    answers_a[14] = "I like to plan key steps ahead.";
    answers_b[14] = "I go with the flow and adapt.";

    questions[15] = "Do you recharge in groups or alone?";
    answers_a[15] = "Group energy helps me recharge.";
    answers_b[15] = "I need solitude to feel energized.";

    questions[16] = "Do you remember impressions or exact details?";
    answers_a[16] = "I remember impressions and themes.";
    answers_b[16] = "I remember exact details and facts.";

    questions[17] = "When stressed, do you seek logic or comfort?";
    answers_a[17] = "I seek comfort and reassurance.";
    answers_b[17] = "I seek logic and solutions.";

    questions[18] = "Do you prefer adaptable decisions or structured ones?";
    answers_a[18] = "I prefer adaptable and flexible decisions.";
    answers_b[18] = "I prefer firm and structured decisions.";

    questions[19] = "Are you motivated by ideas or practical outcomes?";
    answers_a[19] = "Ideas and possibilities motivate me.";
    answers_b[19] = "Practical results drive me.";
}

int main_menu_choice(void) {
    printf("\n========================================\n");
    printf("        MBTI PERSONALITY TEST\n");
    printf("========================================\n");
    printf("1) Take a new MBTI test\n");
    printf("2) View past results\n");
    printf("3) Exit\n");
    printf("========================================\n");
    printf("Choose (1-3): ");

    char choice = get_choice();

    if (choice == '1') return 1;
    if (choice == '2') return 2;
    if (choice == '3') return 3;
    return 0;
}

void sanitize_input(char *text) {
    size_t len = strlen(text);

    if (len > 0 && text[len - 1] == '\n') {
        text[len - 1] = '\0';
    }

    for (size_t i = 0; text[i] != '\0'; ++i) {
        if (text[i] >= 'A' && text[i] <= 'Z') {
            text[i] = (char)(text[i] + ('a' - 'A'));
        }
    }
}

int main(void) {
    const char *questions[MAX_QUESTIONS];
    const char *answers_a[MAX_QUESTIONS];
    const char *answers_b[MAX_QUESTIONS];

    /* Dimension: 0 = E/I, 1 = N/S, 2 = F/T, 3 = J/P.
       A polarity: +1 means answer A matches E, N, F, or J;
                   -1 means answer A matches I, S, T, or P. */
    const int dimensions[MAX_QUESTIONS] = {
        0, 1, 2, 3, 0, 1, 2, 3, 0, 1,
        2, 3, 1, 2, 3, 0, 1, 2, 3, 1
    };

    const int a_polarity[MAX_QUESTIONS] = {
        1, 1, 1, 1, 1, 1, 1, -1, 1, 1,
        1, -1, 1, 1, 1, 1, 1, 1, -1, 1
    };

    build_questions(questions, answers_a, answers_b);

    while (1) {
        int choice = main_menu_choice();

        if (choice == 1) {
            char mood[64] = "other";

            printf("\nSelect your current mood:\n");
            printf("Options: happy, sad, anxious, calm, other\n");
            printf("Your mood: ");

            if (fgets(mood, sizeof(mood), stdin) != NULL) {
                sanitize_input(mood);
            }

            int scores[4] = {0, 0, 0, 0};

            ask_questions(scores, questions, answers_a, answers_b,
                          dimensions, a_polarity);

            char mbti[5];
            determine_mbti(scores, mbti);

            printf("\n\n** Calculating your personality type... **\n");
            show_description(mbti, mood);
            save_result(mbti, mood, scores);

            printf("\n(Result saved to %s)\n", HISTORY_FILE);
            press_enter_to_continue();

        } else if (choice == 2) {
            view_history();
            press_enter_to_continue();

        } else if (choice == 3) {
            printf("\nThank you for using the MBTI test. Goodbye!\n\n");
            break;

        } else {
            printf("\nInvalid choice. Please try again.\n");
        }
    }

    return 0;
}
