# MBTI Personality Explorer

A console-based MBTI-style personality quiz written in C. The program asks 20 questions, generates a four-letter result, displays a short description, asks for the user's current mood, and saves test history to a text file.

> **Note:** This is a small educational programming project, not a clinically validated or official MBTI assessment. Results are for self-reflection only.

## Features

- 20 multiple-choice questions
- Four personality preference dimensions
- Descriptions for 16 possible four-letter types
- Mood-aware tips for happy, sad, anxious, calm, or other moods
- Save results with date and time to `results.txt`
- View previously saved results

## Project structure

```text
MBTI-Personality-Explorer/
├── README.md
├── .gitignore
├── src/
│   └── main.c
├── screenshots/
│   └── README.md
└── report/
    └── MBTI-Project-Report.pdf
```

## Requirements

- A C compiler that supports C99 or later (for example, GCC)
- Windows, macOS, or Linux terminal

## Compile and run

From the repository's root directory:

### Linux / macOS

```bash
gcc -std=c99 -Wall -Wextra src/main.c -o mbti
./mbti
```

### Windows (MinGW)

```bash
gcc -std=c99 -Wall -Wextra src/main.c -o mbti.exe
mbti.exe
```

The program creates `results.txt` in the current working directory when a result is saved.

## Concepts practiced

- Functions and modular program structure
- Arrays and loops
- Conditional statements
- User input and string handling
- File input/output
- Basic date and time handling

## Author

**Maroua Elhaddam**  
Software Engineering Student  
Shandong University of Science and Technology

Developed as a programming practice project.
