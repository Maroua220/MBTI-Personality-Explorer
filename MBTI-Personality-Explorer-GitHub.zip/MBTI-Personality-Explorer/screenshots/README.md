Add screenshots of the program here, such as the main menu and a sample test result.
